README
---

Critter Ranch v1.0

SUMMARY
---
Critter Ranch is a simple management game. Buy and sell critters in order to make nibs and cash and eventually attain the ultimate ranching achievement!

HOW TO PLAY
---
The game is played through mouse interaction with on-screen elements.

Click on critters to see their current status, stats, and selling info

CLick on the shop to buy/sell nibs and sell critters

INSTALLATION
---
THe github repo includes a "Current Build" folder, inside is the build zip file.

Extract and launch CritterRanch.exe

----------------------------------------

CREDITS

----------------------------------------

Programming, Art, Design
---
Xubchas


Fonts
---
004b_03 - Yuji Oshimoto


Music
---
BetaMax Memories - Dream Protocol
Alarm Clock - Lesiakower
NPC Theme -HolzinaCC0
Sunny Afternoon -HolzinaCC0 

SFX 
---
Gameboy pluck - neezen.
PickUp SFX - jhyland
one beep - gamer127
Whoosh SFX - jhyland
Menu_Navigate_00 - LitteRobotSoundFactory 
Jump_00 - LitteRobotSoundFactory 
Collect_Point_01 - LitteRobotSoundFactory 
Hit_01 - LitteRobotSoundFactory 

---
Sounds by LitteRobotSoundFactory licensed under Creative Commons 4.0
https://creativecommons.org/licenses/by/4.0/


Made in Unity2021.3.9f1